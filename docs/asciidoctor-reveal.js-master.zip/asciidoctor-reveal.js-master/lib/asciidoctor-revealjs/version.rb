module Asciidoctor
module Revealjs
  VERSION = '1.0.3-dev'
end
end
