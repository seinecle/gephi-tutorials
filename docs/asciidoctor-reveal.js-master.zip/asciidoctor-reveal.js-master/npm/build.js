var Builder = require('./builder.js');
var builder = new Builder();

builder.build();
